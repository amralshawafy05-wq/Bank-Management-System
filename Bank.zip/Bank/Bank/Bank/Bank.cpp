#include <iostream>
#include <string>
using namespace std;

const int MAX = 500;


void menu();
void addAccount(string names[], int accNums[], double balances[], int pins[], int& count);
void deposit(double balances[], int accNums[], int pins[], int count);
void withdraw(double balances[], int accNums[], int pins[], int count);
void showAccounts(string names[], int accNums[], double balances[], int count);
void searchAccount(string names[], int accNums[], double balances[], int count);
void deleteAccount(string names[], int accNums[], double balances[], int pins[], int& count);

int main() {

    string names[MAX];
    int accNums[MAX];
    double balances[MAX];
    int pins[MAX];

    int count = 0;
    int choice;

    cout << "\n=== Developed Bank System ===\n";

    do {
        menu();
        cin >> choice;

        switch (choice) {
        case 1: addAccount(names, accNums, balances, pins, count); break;
        case 2: deposit(balances, accNums, pins, count); break;
        case 3: withdraw(balances, accNums, pins, count); break;
        case 4: showAccounts(names, accNums, balances, count); break;
        case 5: searchAccount(names, accNums, balances, count); break;
        case 6: deleteAccount(names, accNums, balances, pins, count); break;
        case 7: cout << "Exiting...\n"; break;
        default: cout << "Invalid choice!\n";
        }

    } while (choice != 7);

    return 0;
}

void menu() {
    cout << "\n[1] Add Account";
    cout << "\n[2] Deposit";
    cout << "\n[3] Withdraw";
    cout << "\n[4] Show Accounts";
    cout << "\n[5] Search Account ";
    cout << "\n[6] Delete Account ";
    cout << "\n[7] Exit";
    cout << "\nEnter choice: ";
}


void addAccount(string names[], int accNums[], double balances[], int pins[], int& count) {

    if (count >= MAX) {
        cout << "Bank is full!\n";
        return;
    }

    int newAcc;
    cout << "Enter account number: ";
    cin >> newAcc;


    for (int i = 0; i < count; i++) {
        if (accNums[i] == newAcc) {
            cout << "Account number already exists!\n";
            return;
        }
    }

    cout << "Enter name: ";
    cin >> names[count];

    accNums[count] = newAcc;

    cout << "Enter initial balance: ";
    cin >> balances[count];

    cout << "Set PIN: ";
    cin >> pins[count];

    count++;
    cout << "Account created successfully!\n";
}

void deposit(double balances[], int accNums[], int pins[], int count) {

    int acc, pin;
    double amount;

    cout << "Enter account number: ";
    cin >> acc;

    for (int i = 0; i < count; i++) {
        if (accNums[i] == acc) {

            cout << "Enter PIN: ";
            cin >> pin;

            if (pin != pins[i]) {
                cout << "Wrong PIN!\n";
                return;
            }

            cout << "Enter amount: ";
            cin >> amount;

            balances[i] += amount;
            cout << "Deposit successful!\n";
            return;
        }
    }

    cout << "Account not found!\n";
}

void withdraw(double balances[], int accNums[], int pins[], int count) {

    int acc, pin;
    double amount;

    cout << "Enter account number: ";
    cin >> acc;

    for (int i = 0; i < count; i++) {
        if (accNums[i] == acc) {

            cout << "Enter PIN: ";
            cin >> pin;

            if (pin != pins[i]) {
                cout << "Wrong PIN!\n";
                return;
            }

            cout << "Enter amount: ";
            cin >> amount;

            if (amount <= balances[i]) {
                balances[i] -= amount;
                cout << "Withdraw successful!\n";
            }
            else {
                cout << "Insufficient balance!\n";
            }

            return;
        }
    }

    cout << "Account not found!\n";
}

void showAccounts(string names[], int accNums[], double balances[], int count) {

    if (count == 0) {
        cout << "No accounts!\n";
        return;
    }

    for (int i = 0; i < count; i++) {
        cout << names[i] << " | " << accNums[i]
            << " | Balance: " << balances[i] << endl;
    }
}

void searchAccount(string names[], int accNums[], double balances[], int count) {

    int acc;
    cout << "Enter account number: ";
    cin >> acc;

    for (int i = 0; i < count; i++) {
        if (accNums[i] == acc) {
            cout << "Name: " << names[i]
                << " | Balance: " << balances[i] << endl;
                return;
        }
    }

    cout << "Not found!\n";
}

void deleteAccount(string names[], int accNums[], double balances[], int pins[], int& count) {

    int acc;
    cout << "Enter account number to delete: ";
    cin >> acc;

    for (int i = 0; i < count; i++) {
        if (accNums[i] == acc) {

            for (int j = i; j < count - 1; j++) {
                names[j] = names[j + 1];
                accNums[j] = accNums[j + 1];
                balances[j] = balances[j + 1];
                pins[j] = pins[j + 1];
            }

            count--;
            cout << "Account deleted!\n";
            return;
        }
    }

    cout << "Account not found!\n";
}